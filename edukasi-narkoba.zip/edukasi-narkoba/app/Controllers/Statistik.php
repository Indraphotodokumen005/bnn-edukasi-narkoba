<?php

namespace App\Controllers;

class Statistik extends BaseController
{
    public function index()
    {
        return view('layouts/header', ['title' => 'Statistik'])
            . view('statistik/index')
            . view('layouts/footer');
    }
}
