<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        return view('layouts/header', ['title' => 'Beranda'])
            . view('home/index')
            . view('layouts/footer');
    }
}
