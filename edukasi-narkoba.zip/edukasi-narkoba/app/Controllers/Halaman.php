<?php

namespace App\Controllers;

class Halaman extends BaseController
{
    public function statistik()
    {
        return view('layouts/header', ['title' => 'Statistik'])
            . view('halaman/statistik')
            . view('layouts/footer');
    }

    public function video()
    {
        return view('layouts/header', ['title' => 'Video Edukasi'])
            . view('halaman/video')
            . view('layouts/footer');
    }

    public function infografis()
    {
        return view('layouts/header', ['title' => 'Infografis'])
            . view('halaman/infografis')
            . view('layouts/footer');
    }

    public function tentang()
    {
        return view('layouts/header', ['title' => 'Tentang Kami'])
            . view('halaman/tentang')
            . view('layouts/footer');
    }
}
