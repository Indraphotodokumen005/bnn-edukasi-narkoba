<?php

namespace App\Controllers;

class Tentang extends BaseController
{
    public function index()
    {
        return view('layouts/header', ['title' => 'Tentang Kami'])
            . view('tentang/index')
            . view('layouts/footer');
    }
}
