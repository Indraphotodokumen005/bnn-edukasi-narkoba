<?php

namespace App\Controllers;

use App\Models\ArtikelModel;

class Admin extends BaseController
{
    public function index()
    {
        $model = new ArtikelModel();
        $data['artikel'] = $model->findAll();

        return view('layouts/header', ['title' => 'Admin Dashboard'])
            . view('admin/index', $data)
            . view('layouts/footer');
    }

    public function create()
    {
        return view('layouts/header', ['title' => 'Tambah Artikel'])
            . view('admin/create')
            . view('layouts/footer');
    }

    public function store()
    {
        $model = new ArtikelModel();
        $slug = url_title($this->request->getPost('judul'), '-', true);

        $model->save([
            'judul' => $this->request->getPost('judul'),
            'slug'  => $slug,
            'isi'   => $this->request->getPost('isi')
        ]);

        return redirect()->to('/admin');
    }

    public function delete($id)
    {
        $model = new ArtikelModel();
        $model->delete($id);
        return redirect()->to('/admin');
    }

    public function edit($id)
{
    $model = new \App\Models\ArtikelModel();
    $data['artikel'] = $model->find($id);

    return view('layouts/header', ['title' => 'Edit Artikel'])
        . view('admin/edit', $data)
        . view('layouts/footer');
}


public function update($id)
{
    $model = new ArtikelModel();
    $slug = url_title($this->request->getPost('judul'), '-', true);

    $model->update($id, [
        'judul' => $this->request->getPost('judul'),
        'slug'  => $slug,
        'isi'   => $this->request->getPost('isi')
    ]);

    return redirect()->to('/admin');
}

}
