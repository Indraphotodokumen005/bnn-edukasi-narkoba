<?php

namespace App\Controllers;

class Edukasi extends BaseController
{
    public function index()
    {
        return view('layouts/header', ['title' => 'Edukasi'])
            . view('edukasi/index')
            . view('layouts/footer');
    }

    public function detail($slug)
    {
        return view('layouts/header', ['title' => 'Detail Edukasi'])
            . view('edukasi/detail', ['slug' => $slug])
            . view('layouts/footer');
    }
}
