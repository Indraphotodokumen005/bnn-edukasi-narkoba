<?php

namespace App\Controllers;

class Video extends BaseController
{
    public function index()
    {
        return view('layouts/header', ['title' => 'Video'])
            . view('video/index')
            . view('layouts/footer');
    }
}
