<?php

namespace App\Controllers;

class Infografis extends BaseController
{
    public function index()
    {
        return view('layouts/header', ['title' => 'Infografis'])
            . view('infografis/index')
            . view('layouts/footer');
    }
}
