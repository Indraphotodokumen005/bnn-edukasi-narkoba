<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/home', 'Home::index');

$routes->get('edukasi', 'Edukasi::index');
$routes->get('edukasi/detail/(:segment)', 'Edukasi::detail/$1');

$routes->get('/statistik', 'Statistik::index');
$routes->get('statistik', 'Halaman::statistik');

$routes->get('/video', 'Video::index');
$routes->get('video', 'Halaman::video');
$routes->get('/infografis', 'Infografis::index');
$routes->get('infografis', 'Halaman::infografis');
$routes->get('/tentang', 'Tentang::index');
$routes->get('tentang', 'Halaman::tentang');

$routes->get('admin', 'Admin::index');
$routes->get('admin/create', 'Admin::create');
$routes->post('admin/store', 'Admin::store');
$routes->get('admin/delete/(:num)', 'Admin::delete/$1');
$routes->get('admin/edit/(:num)', 'Admin::edit/$1');
$routes->post('admin/update/(:num)', 'Admin::update/$1');
