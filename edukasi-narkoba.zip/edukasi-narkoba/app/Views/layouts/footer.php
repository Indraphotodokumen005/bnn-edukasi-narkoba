</div> <!-- Tutup container -->

<footer class="bg-light text-center text-lg-start mt-4">
    <div class="text-center p-3">
        © <?= date('Y') ?> Edukasi Narkoba - Semua Hak Dilindungi
    </div>
</footer>

<!-- Optional: Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
