<div class="container py-5">
    <h1 class="mb-4">Artikel Edukasi</h1>
    <p>Berisi kumpulan artikel mengenai bahaya narkoba dan pencegahannya.</p>
</div>
