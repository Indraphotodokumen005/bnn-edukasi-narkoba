<div class="container py-5">
    <h1 class="mb-4">Selamat Datang di Website Edukasi Narkoba BNNK Batang</h1>
    <p>Portal ini menyajikan informasi lengkap tentang bahaya narkoba, jenis-jenis narkoba, hukum terkait, dan upaya pencegahan penyalahgunaan narkoba.</p>
    
    <a href="/edukasi" class="btn btn-primary mt-3">Lihat Artikel Edukasi</a>
</div>
