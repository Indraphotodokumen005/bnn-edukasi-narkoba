<h1>Tambah Artikel</h1>

<form action="<?= base_url('admin/store') ?>" method="post">
    <div class="mb-3">
        <label for="judul" class="form-label">Judul Artikel</label>
        <input type="text" name="judul" id="judul" class="form-control" required>
    </div>

    <div class="mb-3">
        <label for="isi" class="form-label">Isi Artikel</label>
        <textarea name="isi" id="isi" rows="5" class="form-control" required></textarea>
    </div>

    <button type="submit" class="btn btn-primary">Simpan</button>
</form>
