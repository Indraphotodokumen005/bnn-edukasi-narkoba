<h1>Edit Artikel</h1>

<form action="<?= base_url('admin/update/' . $artikel['id']) ?>" method="post">
    <input type="text" name="judul" value="<?= esc($artikel['judul']) ?>" required class="form-control mb-2">
    <textarea name="isi" required class="form-control mb-2"><?= esc($artikel['isi']) ?></textarea>
    <button type="submit" class="btn btn-success">Update</button>
</form>
