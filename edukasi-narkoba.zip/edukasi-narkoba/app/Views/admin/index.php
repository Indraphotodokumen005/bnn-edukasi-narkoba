<!-- app/Views/admin/index.php -->
<h1>Dashboard Admin</h1>

<a href="<?= base_url('admin/create') ?>" class="btn btn-primary mb-3">+ Tambah Artikel</a>


<table class="table table-bordered">
    <thead>
        <tr>
            <th>Judul</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($artikel as $a): ?>
            <tr>
                <td><?= esc($a['judul']) ?></td>
                <td>
                    <a href="<?= base_url('admin/edit/' . $a['id']) ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="<?= base_url('admin/delete/' . $a['id']) ?>" onclick="return confirm('Hapus?')" class="btn btn-danger btn-sm">Hapus</a>

                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
