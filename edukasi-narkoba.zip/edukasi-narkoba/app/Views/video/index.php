<div class="container py-5">
    <h1 class="mb-4">Video Edukasi</h1>
    <p>Kumpulan video kampanye dan edukasi tentang bahaya narkoba.</p>
</div>
