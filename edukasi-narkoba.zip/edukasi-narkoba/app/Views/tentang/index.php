<div class="container py-5">
    <h1 class="mb-4">Tentang Website Ini</h1>
    <p>Website ini dibuat untuk mendukung program edukasi pencegahan narkoba oleh BNN Kabupaten Batang.</p>
</div>
