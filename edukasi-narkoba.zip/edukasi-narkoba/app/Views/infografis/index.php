<div class="container py-5">
    <h1 class="mb-4">Infografis</h1>
    <p>Visualisasi data dan informasi tentang penyalahgunaan narkoba dalam bentuk infografis menarik.</p>
</div>
