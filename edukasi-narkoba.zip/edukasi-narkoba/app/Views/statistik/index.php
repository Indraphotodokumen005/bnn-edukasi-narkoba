<div class="container py-5">
    <h1 class="mb-4">Statistik Penyalahgunaan Narkoba</h1>
    <p>Menampilkan data statistik terkini tentang penyalahgunaan narkoba di Indonesia dan Batang.</p>
</div>
